#include<iostream>
using namespace std;
int main() 
{
	char name[55] = "ABCD" ;						// char a inialize to temp also a
	//cin.get(name,20);
	int i = 0;
	char temp;
	
	while (i <= 7)
	{
		if (name[i]<97)
		{
		//cout << name[i] + 32 << " ";             abcd 97 and greater to 122 , ABCD 65 to 90
		char temp = name[i] + 32 ;
		cout << temp<< "  " ;
		i++;
	}
		else if ( name[i]>=97 )
		{
		//	cout << name[i] - 32 << " " ;
		temp = name[i] - 32 ;
			cout << temp ;
			i++;			//65 to 90
	    }
   }
	return 0;

}
