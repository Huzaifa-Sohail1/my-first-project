#include<iostream>
#include<string>

using namespace std;
int main() 
{
	string name ="1234";
	int i = 0;                              // string letter change to number vice versa in initialize = temp
	while(i<4)
	{
		// cout << name[i] ;
	    int temp = name[i] ;
		int temp2 = temp - 42 ;
		cout << temp2 << " "  ;
		i++;	
  }
return 0;
}
