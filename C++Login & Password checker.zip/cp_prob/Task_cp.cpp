#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct Customer {
    int id;
    string name, phone, address;
};
bool login(const string &filename) {
    ifstream file(filename);
    string username, password, storedUser, storedPass;
    if (!file) {
        cerr << "Error opening login file.\n";
    }
        else {
    cout << "Login file opened successfully.\n";
    }
    getline(file, storedUser);
    getline(file, storedPass);
    file.close();
    while (true) {
        cout << "Enter username: ";
        cin >> username;
        cout << "Enter password: ";
        cin >> password;
        if (username == storedUser && password == storedPass) {
            cout << "Login successful!\n";
            return true;
        } else {
            cout << "Invalid credentials. Try again.\n";
        }
    }
}
void addCustomers(const string &filename) {
    Customer customers[10];
    ofstream file(filename, ios::app);
    if (!file) {
        cerr << "Error opening file for writing.\n";
        } else {
    cout << "Customers file opened successfully.\n";

    }
    for (int i = 0; i < 10; ++i) {
        customers[i].id = i + 1; 
        cout << "Enter details for customer " << customers[i].id << ":\n";
        cout << "Name: ";
        cin.ignore();
        getline(cin, customers[i].name);
        cout << "Phone: ";
        getline(cin, customers[i].phone);
        cout << "Address: ";
        getline(cin, customers[i].address);

        file << customers[i].id << '\n'
             << customers[i].name << '\n'
             << customers[i].phone << '\n'
             << customers[i].address << '\n';
    }

    file.close();
    cout << "10 customers added successfully.\n";
}


void displayAllCustomers(const string &filename) {
    ifstream file(filename);

    if (!file) {
        cerr << "Error opening file for reading.\n";
        return;
    }

    int id;
    string name, phone, address;
    cout << "\nCustomer Data:\n";

    while (file >> id) {
        file.ignore();
        getline(file, name);
        getline(file, phone);
        getline(file, address);

        cout << "ID: " << id << "\n"
             << "Name: " << name << "\n"
             << "Phone: " << phone << "\n"
             << "Address: " << address << "\n";
        cout << "-----------------------\n";
    }

    file.close();
}

void searchCustomerByID(const string &filename) {
    int searchID;
    cout << "Enter the ID of the customer to search: ";
    cin >> searchID;

    ifstream file(filename);

    if (!file) {
        cerr << "Error opening file for reading.\n";
        return;
    }

    int id;
    string name, phone, address;
    bool found = false;

    while (file >> id) {
        file.ignore();
        getline(file, name);
        getline(file, phone);
        getline(file, address);

        if (id == searchID) {
            cout << "\nCustomer Found:\n"
                 << "ID: " << id << "\n"
                 << "Name: " << name << "\n"
                 << "Phone: " << phone << "\n"
                 << "Address: " << address << "\n";
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "No Customer Found.\n";
    }

    file.close();
}

int main() {
    const string customerFile = "Customers.txt";
    const string loginFile = "Login.txt";

    if (!login(loginFile)) {
        return 1;
    }

    char choice;
    bool running = true;

    while (running) {
        cout << "\nMenu:\n";
        cout << "1. Input 10 customers\n";
        cout << "2. Display all data\n";
        cout << "3. Search customer by ID\n";
        cout << "e. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == '1') {
            addCustomers(customerFile);
        } else if (choice == '2') {
            displayAllCustomers(customerFile);
        } else if (choice == '3') {
            searchCustomerByID(customerFile);
        } else if (choice == 'e' || choice == 'E') {
            cout << "Exiting the program.\n";
            running = false;
        } else {
            cout << "Invalid choice. Please enter 1, 2, 3, or e.\n";
        }
    }
    return 0;
}