#include <iostream>
#include <string>

using namespace std;

// Define the structure
struct Customer {
    string name;
    int account_number;
    double balance;
};

// Function to print names of customers with balance less than $200
void printLowBalanceCustomers(Customer customers[], int size) {
    cout << "\nCustomers with balance less than $200:\n";
    for (int i = 0; i < size; i++) {
        if (customers[i].balance < 200) {
            cout << customers[i].name << endl;
        }
    }
}

// Function to add $100 to customers with balance greater than $1000 and display new balance
void addBonusToRichCustomers(Customer customers[], int size) {
    cout << "\nCustomers with balance more than $1000 (after adding $100):\n";
    for (int i = 0; i < size; i++) {
        if (customers[i].balance > 1000) {
            customers[i].balance += 100; // Add $100 to balance
            cout << "Account No: " << customers[i].account_number
                 << " | Name: " << customers[i].name
                 << " | New Balance: $" << customers[i].balance << endl;
        }
    }
}

int main() {
    const int num_customers = 50;
    Customer customers[num_customers];

    // Taking input for 50 customers
    for (int i = 0; i < num_customers; i++) {
        cout << "\nEnter details for Customer " << i + 1 << ":\n";

        cout << "Enter Name: ";
        cin.ignore();
        getline(cin, customers[i].name);

        cout << "Enter Account Number: ";
        cin >> customers[i].account_number;

        cout << "Enter Balance: ";
        cin >> customers[i].balance;
    }

    // Function calls
    printLowBalanceCustomers(customers, num_customers);
    addBonusToRichCustomers(customers, num_customers);

    return 0;
}