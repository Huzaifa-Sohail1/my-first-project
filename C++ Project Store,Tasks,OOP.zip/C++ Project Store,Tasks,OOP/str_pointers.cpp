#include <iostream>
#include <cstring>
using namespace std;

void reverseString(char* str) {
    char* start = str;               // Pointer to the start of the string
    char* end = str + strlen(str) - 1; // Pointer to the end of the string
    char temp;
cout << start ;
    while (start < end) {
        // Swap the characters
        temp = *start;
        *start = *end;
        *end = temp;
  cout <<"\n" << start << "      " <<  end << "\n" ;
        // Move the pointers
        start++;
        end--;
    }
}

int main() {
    char str[100];

    cout << "Enter a string:\n " ;
    cin.getline(str, 100); // Input a string

    reverseString(str);

    cout << "Reversed string: " << str << endl;

    return 0;
}