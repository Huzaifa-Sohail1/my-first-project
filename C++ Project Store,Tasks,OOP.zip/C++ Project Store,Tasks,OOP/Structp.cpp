#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct student
{
    string name;
    int roll_no;
    float marks;
} s[2];

void saveToFile()
{
    ofstream file("student_details.txt");
    if (!file)
    {
        cerr << "Error opening file for writing!" << endl;
        return;
    }

    for (int i = 0; i < 2; i++)
    {
        file << s[i].roll_no << s[i].name << s[i].marks << endl;
    }

    file.close();
    cout << "Details saved to file successfully." << endl;
}

void readFromFile()
{
    ifstream file("student_details.txt");
    if (!file)
    {
        cerr << "Error opening file for reading!" << endl;
        return;
    }

    cout << endl
         << "====Displaying Information from File====" << endl;
    string name;
    int roll_no;
    float marks;

    // while (file >> roll_no >> name >> marks) {
    //     cout << "Roll no: " << roll_no << endl;
    //     cout << "Name: " << name << endl;
    //     cout << "Marks: " << marks << endl;
    //     cout << endl;
    // }

    string line;
    int i = 0;
    while (i < 2)
    {
        getline(file, line);
        cout << line;
        i++;
        // cout << "Roll no: " << roll_no << endl;
        // cout << "Name: " << name << endl;
        // cout << "Marks: " << marks << endl;
        cout << endl;
    }

    file.close();
}

int main()
{
    // cout << "Enter student details:" << endl;
    // for (int i = 0; i < 2; i++) {
    //     s[i].roll_no = i + 1;
    //     cout << "For Roll no: " << s[i].roll_no << endl;
    //     cout << "Enter Name: ";
    //     cin >> s[i].name;
    //     cout << "Enter Marks: ";
    //     cin >> s[i].marks;
    // }

    // saveToFile(); // Save details to file

    // cout << endl << "====Displaying Information====" << endl;
    // for (int i = 0; i < 2; i++) {
    //     cout << "For Roll no: " << i + 1 << endl;
    //     cout << "Name: " << s[i].name << endl;
    //     cout << "Marks: " << s[i].marks << endl;
    //     cout << endl;
    // }

    readFromFile(); // Read details from file

    return 0;
}
