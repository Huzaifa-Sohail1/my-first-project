//display the output using function. Pass the structure object in function first by value and then by reference.
#include <iostream>
#include <string>
using namespace std;

// Define the structure
struct Employee {
    int EmpID;
    string EmpName;
    int EmpAge;
    double EmpSalary;
};

// Function to display employee details (Pass by Value)
void displayByValue(Employee emp) {
    cout << "\n(Employee Details - Pass by Value)\n";
    cout << "ID: " << emp.EmpID << endl;
    cout << "Name: " << emp.EmpName << endl;
    cout << "Age: " << emp.EmpAge << endl;
    cout << "Salary: $" << emp.EmpSalary << endl;
}

// Function to display employee details (Pass by Reference)
void displayByReference(Employee &emp) {
    cout << "\n(Employee Details - Pass by Reference)\n";
    cout << "ID: " << emp.EmpID << endl;
    cout << "Name: " << emp.EmpName << endl;
    cout << "Age: " << emp.EmpAge << endl;
    cout << "Salary: $" << emp.EmpSalary << endl;
}

int main() {
    Employee emp;

    // Taking input from the user
    cout << "Enter Employee ID: ";
    cin >> emp.EmpID;
    cin.ignore(); // Ignore the newline character after entering ID

    cout << "Enter Employee Name: ";
    getline(cin, emp.EmpName);

    cout << "Enter Employee Age: ";
    cin >> emp.EmpAge;

    cout << "Enter Employee Salary: ";
    cin >> emp.EmpSalary;

    // Displaying using function (Pass by Value)
    displayByValue(emp);

    // Displaying using function (Pass by Reference)
    displayByReference(emp);

    return 0;
}