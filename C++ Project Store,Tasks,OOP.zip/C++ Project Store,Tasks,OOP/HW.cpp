#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    char arr[]= "Bahria University";
    int length1, length2;
    length1 = strlen (arr);
    length2 = strlen ("Hello world");
    cout<<length1<<endl;
    cout<<arr[16]<<endl;
    cout<<length2<<endl;
    return 0;
}