#include <iostream>
using namespace std;
int main()
 {
    int a;
    cout << "Enter the number of elements in the array: ";
    cin >> a;
    if (a < 2) 
    {
        cout << "Array must have at least 2 elements to find the second smallest element." << endl;
        return 0;
    }
    int arr[a];
    cout << "Enter " << a << " elements:\n";
    for (int i = 0; i < a; ++i) 
    {
        cin >> arr[i];
    }
    int smallest = arr[0];
    int secondSmallest = arr[0];
    for (int i = 1; i < a; ++i) {
        if (arr[i] < smallest) {
            secondSmallest = smallest; 
            smallest = arr[i];         
        } else if (arr[i] > smallest && (secondSmallest == smallest || arr[i] < secondSmallest)) {
            secondSmallest = arr[i]; 
        }
    }
    if (secondSmallest == smallest) {
        cout << "There is no second smallest element in the array." << endl;
    } else {
        cout << "The second smallest element in the array is: " << secondSmallest << endl;
    }
    return 0;
}
