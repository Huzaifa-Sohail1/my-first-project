#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    char source[]="folks";
    char target[]="hello";
    int i,j,k;
    i = strcmp( source,"folks");
    j = strcmp( source, target);
    k = strcmp( source,"Jerry boy");   
    cout << i <<"  "<< j << "  " << k << "  "<<source << " " << target  ;
}