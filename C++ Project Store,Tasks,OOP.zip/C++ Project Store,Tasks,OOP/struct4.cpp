#include <iostream>
#include <string>

using namespace std;

// Define the structure
struct Marks {
    int roll_no;
    string name;
    float cp_marks;
    float ict_marks;
    float oop_marks;
};

// Function to calculate and display percentage
void displayPercentage(Marks student) {
    float total = student.cp_marks + student.ict_marks + student.oop_marks;
    float percentage = (total / 300) * 100;

    cout << "\nStudent Details:\n";
    cout << "Roll No: " << student.roll_no << endl;
    cout << "Name: " << student.name << endl;
    cout << "Computer Programming Marks: " << student.cp_marks << endl;
    cout << "ICT Marks: " << student.ict_marks << endl;
    cout << "Object-Oriented Programming Marks: " << student.oop_marks << endl;
    cout << "Percentage: " << percentage << "%\n";
}

int main() {
    const int num_students = 5;
    Marks students[num_students];

    // Taking input for 5 students
    for (int i = 0; i < num_students; i++) {
        cout << "\nEnter details for Student " << i + 1 << ":\n";

        cout << "Enter Roll No: ";
        cin >> students[i].roll_no;
        cin.ignore(); // Ignore newline character

        cout << "Enter Name: ";
        getline(cin, students[i].name);

        cout << "Enter Computer Programming Marks (out of 100): ";
        cin >> students[i].cp_marks;

        cout << "Enter ICT Marks (out of 100): ";
        cin >> students[i].ict_marks;

        cout << "Enter Object-Oriented Programming Marks (out of 100): ";
        cin >> students[i].oop_marks;
    }

    // Displaying results
    cout << "\n===== Student Results =====";
    for (int i = 0; i < num_students; i++) {
        displayPercentage(students[i]);
    }

    return 0;
}
