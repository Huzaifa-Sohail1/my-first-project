#include<iostream>
#include <iomanip>
#include <fstream>  
using namespace std;

void displaypurchasemenu(int inventory[]) {
    cout << endl;
    cout << "\t\t  ---------------------------------------" << endl;
    cout << "\t\t          PURCHASE MENU" << endl;
    cout << "\t\t  ---------------------------------------" << endl;
    cout << "\t\t  Sr.No    PRODUCT    PRICE    QUANTITY LEFT" << endl;
    cout << "\t\t     1        A-a      99        " << inventory[0] << endl;
    cout << "\t\t     2        B-b      340       " << inventory[1] << endl;
    cout << "\t\t     3        C-c      999       " << inventory[2] << endl;
    cout << "\t\t     4        D-d      847       " << inventory[3] << endl;
    cout << "\t\t     5        E-e      9099      " << inventory[4] << endl;
    cout << "\t\t     6        F-f      59        " << inventory[5] << endl;
    cout << "\t\t     7        G-g      69        " << inventory[6] << endl;
    cout << "\t\t     8        H-h      2700      " << inventory[7] << endl;
    cout << "\t\t     9        I-i      5000      " << inventory[8] << endl;
    cout << "\t\t     10       J-j      270       " << inventory[9] << endl;
}

// Function to save data to a file
void saveDataToFile(string name, int token, string item_names[], int price[], int quan[], int total_items, int totalprice, int cash, int returned, int inventory[]) {
    ofstream file("Purchase_data.txt", ios::app); 
    if (!file) {
        cout << "Error opening file for writing." << endl;
        return;
    }

    // Customer info
    file << "\n======================== PURCHASE RECEIPT ========================\n";
    file << "Customer Name  : " << name << endl;
    file << "Token Number   : " << token << endl;
    file << "Items Purchased:\n";

    // Write purchased items details
    for (int i = 0; i < total_items; i++) {
        if (price[i] != 0) {  
            file << "Item Name: " << item_names[i] << ", Quantity: " << quan[i] << ", Price: Rs." << price[i] << ", Total: Rs." << (price[i] * quan[i]) << endl;
        }
    }

    // Total price, cash, and change
    file << "Total Price     : Rs." << totalprice << endl;
    file << "Cash Provided   : Rs." << cash << endl;
    file << "Returned        : Rs." << returned << endl;

    // Save the updated inventory to the file
    file << "\nUpdated Inventory:\n";
    for (int i = 0; i < 10; i++) {
        file << "Product " << (char)('A' + i) << " : " << inventory[i] << endl;
    }
    
    file << "====================================================================\n";
    file.close();
}

int main() {
    string name;
    int token, option, total_items, cash = 0, returned = 0;
    char again;

  
    int inventory[10] = {100, 50, 30, 20, 10, 200, 150, 25, 5, 40};  
    cout << endl;
    cout << "\t\t  -----------------------------------" << endl;
    cout << "\t\t     WELCOME TO SAUOOD SUPERMART" << endl;
    cout << "\t\t  -----------------------------------" << endl;
    cout << "\t\t ------------------------------------------" << endl;
    cout << "  \t\t Enter Your Name : ";
    getline(cin, name);
    cout << "  \t\t Enter Your Token number : ";
    cin >> token;
    cout << "\t\t ------------------------------------------" << endl;

    // Do-while loop to allow multiple transactions
    do {
        cout << "\t\t  -----------------------------------" << endl;
        cout << "\t\t  MAIN MENU" << endl;
        cout << "\t\t 1. BILL MENU" << endl;
        cout << "\t\t 2. EXIT" << endl;
        cout << "\t\t  -----------------------------------" << endl;
        cout << "Select Your Option (1 or 2): ";
        cin >> option;
     
        if (option == 1) {
            system("CLS");
            displaypurchasemenu(inventory);  
            cout << "\n\t\t\t PLACE YOUR ORDER" << endl;
            cout << "\t\t  -----------------------------------" << endl;
            cout << "\t\t ENTER NUMBER OF ITEMS YOU WANT TO BUY : ";
            cin >> total_items;

            // arrays to store item details
            string item_names[total_items];
            int price[total_items] = {0}; 
            int sr_No[total_items];
            int quan[total_items];
            int totalprice = 0;

            for (int i = 0; i < total_items; i++) {
                cout << "\t\tEnter item name (A, B, C, etc.): ";
                cin >> item_names[i];

                // Product Selection and price assignment
                if (item_names[i] == "A" || item_names[i] == "a") {
                    price[i] = 99;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "B" || item_names[i] == "b") {
                    price[i] = 340;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "C" || item_names[i] == "c") {
                    price[i] = 999;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "D" || item_names[i] == "d") {
                    price[i] = 847;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "E" || item_names[i] == "e") {
                    price[i] = 9099;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "F" || item_names[i] == "f") {
                    price[i] = 59;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "G" || item_names[i] == "g") {
                    price[i] = 69;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "H" || item_names[i] == "h") {
                    price[i] = 2700;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "I" || item_names[i] == "i") {
                    price[i] = 5000;
                    sr_No[i] = i + 1;
                }
                else if (item_names[i] == "J" || item_names[i] == "j") {
                    price[i] = 270;
                    sr_No[i] = i + 1;
                }
                else {
                    cout << "\nPlease Enter a Valid Product" << endl;
                    price[i] = 0;  
                    continue;      
                }
                cout << "\t\t The price is: Rs." << price[i] << endl;
                cout << "\t\t The Product No. is: " << sr_No[i] << endl;
                cout << "\t\t Quantity: ";
                cin >> quan[i];

                if (quan[i] > inventory[sr_No[i] - 1]) {
                    cout << "Sorry, we only have " << inventory[sr_No[i] - 1] << " of product " << item_names[i] << endl;
                    cout << "Enter  smaller quantity: ";
                    cin >> quan[i];
                }

                inventory[sr_No[i] - 1] -= quan[i];
                cout << "Remaining stock of " << item_names[i] << ": " << inventory[sr_No[i] - 1] << endl;
            }

            // Display the receipt
            system("CLS");
            cout << "\t\t\t\t BUYER " << endl;
            cout << "\t\t  NAME     : " << name << endl;
            cout << "\t\t  TOKEN    : " << token << endl;

            cout << "\n\t\t ****************** RECEIPT *******************" << endl;
            cout << "\t\t Sr.No    Product    Quantity    Price   Total" << endl;
            cout << "\t\t **********************************************" << endl;

            // Display purchased items
            for (int i = 0; i < total_items; i++) {
                if (price[i] != 0) {  
                    int total = price[i] * quan[i];
                    totalprice += total;
                    cout << "\t\t" << setw(6) << sr_No[i] << setw(10) << item_names[i] << setw(10) << quan[i]
                         << setw(10) << price[i] << setw(9) << total << endl;
                }
            }

            cout << "\t\t **********************************************" << endl;
            cout << "\t\t THE TOTAL PRICE = Rs " << totalprice << endl;
            cout << "\t\t      ENTER CASH = Rs ";
            cin >> cash;

            if (totalprice <= cash) {
                returned = cash - totalprice;
                cout << "\t\t\tRETURNED = Rs " << returned << endl;
                cout << "\t\t **********************************************" << endl;
                cout << "\t\t\t THANK YOU FOR PLACING YOUR ORDER" << endl;

                saveDataToFile(name, token, item_names, price, quan, total_items, totalprice, cash, returned, inventory); 
            }
            else {
                cout << "\n\t\t **********************************************" << endl;
                cout << "\t\t YOU DO NOT HAVE ENOUGH MONEY!" << endl;
                cout << "\t\t **********************************************" << endl;
            }
        } else if (option == 2) {
            cout << "\t\t **********************************************" << endl;
            cout << "\t\t\t   THANK YOU FOR COMING!!!!" << endl;
            cout << "\t\t **********************************************" << endl;
            break;
        }

        cout << "\n\nDo You Want To Buy Again?" << endl;
        cout << "Type Y if YES, Type N for NO: ";
        cin >> again;
        system("CLS");

    } while (again == 'y' || again == 'Y');

    return 0;
}

