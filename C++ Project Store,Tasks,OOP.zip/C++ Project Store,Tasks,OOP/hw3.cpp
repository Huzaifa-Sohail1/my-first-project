#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    char source[]="folk";
    char target[11]="hello";
    strcat(target,source);
    cout<< source<<endl;
    cout<< target<<endl;
}