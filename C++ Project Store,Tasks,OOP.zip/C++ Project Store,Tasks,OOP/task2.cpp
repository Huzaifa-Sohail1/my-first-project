#include <iostream>
using namespace std;

int main() {
  int a; 
    cout<<"Enter the number of elements in the array :";
    cin>>a;
    int arr[a];
    for (int i = 0; i < a; ++i) {
        cin>>arr[i]; 
    }
    int sum = 0; 
    for (int i = 0 ; i < a; ++i)
     {
        sum =sum +  arr[i]; 

    }
    cout<<"The sum of all elements in the array is :"<<sum<<endl;
    return 0;
}