#include <iostream>

void bubbleSortWithIndices(int arr[], int indices[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {        //arr     = {1, 2, 3, 90, 55, 75, 37, 95, 55}  Before
                                                        //indices = {0, 1, 2, 3, 4, 5, 6, 7, 8}
            if (arr[j] > arr[j + 1]) {
                // Swap elements in the array
                int temp = arr[j];          //90
                arr[j] = arr[j + 1];        //55 ,75
                arr[j + 1] = temp;      //90 ,90

                // Swap corresponding indices
                temp = indices[j];         //3,          j=4
                indices[j] = indices[j + 1];   //4
                indices[j + 1] = temp;     //3       
                                                         //arr     = {1, 2, 3, 37, 55, 55, 75, 90, 95}  After
                                             //indices = {0, 1, 2, 6, 4, 8, 5, 3, 7}
            }
        }
    }
}
void binarySearchAndFrequency(int arr[], int indices[], int size, int target) {
    // Sort the array and maintain original indices
    bubbleSortWithIndices(arr, indices, size);

    // Perform binary search
    int left = 0, right = size - 1, mid;
    bool found = false;

    while (left <= right) {
        mid = left + (right - left) / 2;

        if (arr[mid] == target) {
            found = true;
            break;
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    if (found) {
        // Count frequency of the target
        int frequency = 1;

        // Print the original location of the found element
        std::cout << "Element " << target << " found at original location(s): array[" << indices[mid] << "]";

        // Count occurrences on the left of `mid`
        for (int i = mid - 1; i >= 0 && arr[i] == target; i--) {
            std::cout << ", array[" << indices[i] << "]";
            frequency++;
        }

        // Count occurrences on the right of `mid`
        for (int i = mid + 1; i < size && arr[i] == target; i++) {
            std::cout << ", array[" << indices[i] << "]";
            frequency++;
        }

        std::cout << "\nFrequency of " << target << ": " << frequency << "\n";
    } else {
        std::cout << "Element " << target << " not found in the array.\n";
    }
}

int main() {
    int arr[] = {17,20,10,9,23,13,12,19,18,24
                ,12,14,6,9,13,6,7,10,13,7
                ,16,18,8,13,3,32,9,7,10,11
                ,13,7,18,7,10,4,27,19,16,8
                ,7,10,5,14,15,10,9,6,7,15};
    int size = sizeof(arr) / sizeof(arr[0]);
    int indices[size];

    // Initialize the indices array to store original positions
    for (int i = 0; i < size; i++) {
        indices[i] = i;
    }                       //indices = {0, 1, 2, 3, 4, 5, 6, 7, 8}

    int target;
    std::cout << "Enter the element to search: ";
    std::cin >> target;

    binarySearchAndFrequency(arr, indices, size, target);

    return 0;
}
