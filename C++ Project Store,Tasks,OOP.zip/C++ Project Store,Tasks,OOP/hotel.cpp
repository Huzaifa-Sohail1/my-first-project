#include <iostream>
using namespace std;

class HotelRoom {
private:
    int roomNumber;
    bool isBooked;

public:
    // Constructor
    HotelRoom(int number) {
        roomNumber = number;
        isBooked = false;
    }

    // Getter method
    int getRoomNumber() { return roomNumber; }

    // Setter method
    void bookRoom() { isBooked = true; }

    // Getter for booking status
    bool checkAvailability() { return !isBooked; }
};

int main() {
    HotelRoom room1(101);

    // Accessing data through methods
    cout << "Room Number: " << room1.getRoomNumber() << endl;
    cout << "Available: " << room1.checkAvailability() << endl;

    room1.bookRoom();
    cout << "Available after booking: " << room1.checkAvailability() << endl;

    return 0;
}
