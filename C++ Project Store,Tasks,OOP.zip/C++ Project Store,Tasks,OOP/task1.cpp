#include <iostream>
using namespace std;
int main() {
    int a; 
    cout << "Enter the number of elements in the array :";
    cin >> a;
    int arr[a];
    cout << "Enter " << a << " elements :\n";
    for (int i = 0 ; i < a ; ++i) {
        cin >> arr[i];
    }
 int even_count = 0, odd_count = 0;
    for (int i = 0; i < a; ++i) {
        if (arr[i] % 2 == 0) {
            ++even_count; 
        } else {
            ++odd_count; 
        }
    }
   cout << "Number of even elements :" << even_count << endl;
    cout << "Number of odd elements :" << odd_count << endl;
    return 0;
}
