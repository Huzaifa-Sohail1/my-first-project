#include <iostream>
#include <string>

using namespace std;

// Define the structure
struct Employee {
    int EmpID;
    string EmpName;
    int EmpAge;
    double EmpSalary;
};

int main() {
    Employee *emp = new Employee; // Dynamically allocating memory

    // Taking input from the user using pointer
    cout << "Enter Employee ID: ";
    cin >> emp->EmpID;
    cin.ignore(); // Ignore the newline character after entering ID

    cout << "Enter Employee Name: ";
    getline(cin, emp->EmpName);

    cout << "Enter Employee Age: ";
    cin >> emp->EmpAge;

    cout << "Enter Employee Salary: ";
    cin >> emp->EmpSalary;

    // Displaying employee details using pointer
    cout << "\nEmployee Details:\n";
    cout << "ID: " << emp->EmpID << endl;
    cout << "Name: " << emp->EmpName << endl;
    cout << "Age: " << emp->EmpAge << endl;
    cout << "Salary: $" << emp->EmpSalary << endl;

    delete emp; // Free allocated memory

    return 0;
}
