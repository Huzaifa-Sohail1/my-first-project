#include<iostream>
using namespace std;
int main()
 {
    int a; 
    cout << "Enter the number of elements in the array: ";
    cin >> a;
    int arr[a]; 
    cout << "Enter " << a << " elements:\n";
    for (int i = 0; i < a; ++i)
     {
        cin >> arr[i]; 
    }
    int max_element = arr[0]; 

    for (int i = 1; i < a; ++i) 
    { 
        if (arr[i] > max_element) 
        {
            max_element = arr[i]; 
        }
    }
    cout << "The maximum element in the array is: " << max_element << endl;
    return 0;
}


