#include<iostream>
using namespace std;
int main()
{
    int n;    
    cout<<"Enter total number of elements";                                  //10 7 4 6 8 10 11    max common difference
    cin >> n;                                                                //4 6 8 10   Output : 4
    int array[n];
    for (int i=0 ; i<n ; i++)
    {
        cout<< "Enter arrays elements :";
        cin >>array[i];
    }
    int pcd = array[1] - array[0] ;
    int current = 2;
    int ans =2;
    int j=2;
    while (j<n)
    {
        if (pcd == array[j] - array[j-1] )
        {
            current++;
            cout << array[j] << " " << pcd << " " << current << endl ;
        }
        else
        {
            pcd = array[j] - array[j-1];
            current=2;
        }
        ans=max(ans,current);
        j++;
        cout << " " << ans << " " << j << endl ;
    }
    cout<<"Output is :"<<ans;
    return 0;
}