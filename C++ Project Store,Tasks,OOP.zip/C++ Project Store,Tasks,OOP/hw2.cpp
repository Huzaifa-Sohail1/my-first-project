#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    char source [] ="BSCS 1";
    char target [1] ;
    strcpy(source,target);
    cout<<"Source string :"<<source<<endl;
    cout<<"Target string :"<<target<<endl;   
    return 0;
}