#include <iostream>
using namespace std;
int main() {
    int a;  
    cout<< "Enter the number of salespeople :";                
    cin >> a;
    int sales[a];                                               // 1st time store numbers of customer   Example 4 or 5 or 10
    cout<< "Enter the gross sales for each salesperson :\n";
    for (int i = 0; i < a; ++i) {
        cin >> sales[i];                                       // 2nd time store values in Amount like in 1st value ,2... example 5000,4321
    }
    
    int salaryRanges[9] = {0};                                  // others are supposed zero salaryRanges[2]=0 so start is zero
    for (int i = 0; i < a-2; ++i) {
        int salary = 200 + (9 * sales[i]) / 100;  
        if (salary >= 200 && salary <= 299) {
            salaryRanges[0]++;
        } else if (salary >= 300 && salary <= 399) {
            salaryRanges[1]++;
        } else if (salary >= 400 && salary <= 499) {
            salaryRanges[2]++;
        } else if (salary >= 500 && salary <= 599) {
            salaryRanges[3]++;
        } else if (salary >= 600 && salary <= 699) {
            salaryRanges[4]++;
        } else if (salary >= 700 && salary <= 799) {
            salaryRanges[5]++;
        } else if (salary >= 800 && salary <= 899) {
            salaryRanges[6]++;
        } else if (salary >= 900 && salary <= 999) {
            salaryRanges[7]++;
        } else if (salary >= 1000) {
            salaryRanges[8]++;
        }
    }
    cout<<"\nSalary Range  | Number of Salespeople\n";
    cout<<"-----------------------------------------\n";
    cout<<"$200 - 299    | "<< salaryRanges[0] <<endl;
    cout<<"$300 - 399    | "<< salaryRanges[1] <<endl;
    cout<<"$400 - 499    | "<< salaryRanges[2] <<endl;
    cout<<"$500 - 599    | "<< salaryRanges[3] <<endl;
    cout<<"$600 - 699    | "<< salaryRanges[4] <<endl;
    cout<<"$700 - 799    | "<< salaryRanges[5] <<endl;
    cout<<"$800 - 899    | "<< salaryRanges[6] <<endl;
    cout<<"$900 - 999    | "<< salaryRanges[7] <<endl;
    cout<<"$1000 and over| "<< salaryRanges[8] <<endl;
    return 0;
}
