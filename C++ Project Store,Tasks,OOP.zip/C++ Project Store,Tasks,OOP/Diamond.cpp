#include<Iostream>
using namespace std;
int main ()
{
    int size = 5;
   
    cout << "Enter size : " << endl ;

        for (int line = 1  ; line <=size ; line ++){
            for(int space = 1 ; space <= size - line ; space ++){
                cout << " " ;
            }
                for(int star = 1 ; star <= 2*line-1 ; star++)
                {
                    cout << "*" ;
                }
            
        
        cout << endl ;
             
    }
    for (int line = size-1  ; line >=1 ; line --){
        for(int space = 1 ; space <= size - line ; space ++){
            cout << " " ;
        }
            for(int star = 1 ; star <= 2*line-1 ; star++)
            {
                cout << "*" ;
            }
        
    
    cout << endl ;
         
}
    
    return 0;
}