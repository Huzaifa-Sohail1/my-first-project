#include <iostream>
using namespace std;
class Time {
private:
    int hour, minute, second;
public:
    Time() : hour(0), minute(0), second(0) {}

    void display() {
        if (hour < 10) cout << "0";
        cout << hour << ":";
        if (minute < 10) cout << "0";
        cout << minute << ":";
        if (second < 10) cout << "0";
        cout << second << endl;
    }

    void ticktick() {
        second++;
        if (second == 60) {
            second = 0;
            minute++;
        }
        if (minute == 60) {
            minute = 0;
            hour++;
        }
        if (hour == 24) {  // Reset hour after 24 hours
            hour = 0;
        }
    }
};

int main() {
    Time t;
    cout << "Initial time: ";
    t.display();
    
    for (int i = 0; i < 3661; i++) { // Increment time by 3661 seconds
        t.ticktick();
    }
    
    cout << "Time after ticking for 3661 seconds: ";
    t.display();

    return 0;
}