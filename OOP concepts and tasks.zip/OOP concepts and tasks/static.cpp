// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

void fun() {
 static int count = 0;
 if ( count != 4)
  {
  count++;
  }
 cout << count << " ";
}
int main() {
 fun();
 static int count =9 ;
 fun();
 fun();
 fun() ;
 cout << count ;
 return 0;
}