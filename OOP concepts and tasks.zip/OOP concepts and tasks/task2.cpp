#include <iostream>
using namespace std ;
class Area {
	private:
		float PI=3.1419;
		float radius ;
	public:
		Area(double pi , int ) : PI(pi) ,radius(0.0)
		{
		}
		void inputRadius ()
		{ 
			cout << " Enter radius :"  ;
			cin >> radius ;
		}
		double surfacearea (){
			return 4 * PI * radius  ;
		}
		double areaofcircle() {
			return PI *radius *radius ;
		}
		void display ()
		{
			cout << surfacearea() << endl ;
			cout << areaofcircle() << endl ;
		}
};
int main ()
{
	Area area(3.1419 , 45);
	area.inputRadius() ;
	area.display();
}