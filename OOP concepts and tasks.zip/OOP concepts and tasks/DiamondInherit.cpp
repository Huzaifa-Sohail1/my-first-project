#include <iostream>
using namespace std;

class A {
public:
    A(){cout <<" A..";}
    void show() {
        cout << "Class A" << endl;
    }
};
class B : virtual public A {};  // Virtual inheritance
class C : virtual public A {
    public:
    static double calculateArea(double length, double width) {   // static funt no impact But static var does by func
        double var = length * width ; 
        var ++ ;
        return var;  // Example formula
    }
};  // Virtual inheritance
class D : virtual public B , virtual public C{};  // Inherits A only once
int main() {
    D obj;
    C obj1;
    obj.show();  // No ambiguity
    cout << D::calculateArea(7, 6) << endl ;
    cout << obj1.calculateArea(9,10) << endl;\
    int store = obj1.calculateArea(9,10) + C::calculateArea(7, 6) ;
    cout << store ;
    return 0;
}

/*#include <iostream>
using namespace std;

class A {
public:
    void show() {
        cout << "Class A" << endl;
    }
};

class B : public A {};  // B inherits A
class C : public A {};  // C inherits A

class D : public B, public C {};  // D inherits both B and C

int main() {
    D obj;
    obj.show(); // ERROR: Ambiguous call to 'show()'
    return 0;
}
*/