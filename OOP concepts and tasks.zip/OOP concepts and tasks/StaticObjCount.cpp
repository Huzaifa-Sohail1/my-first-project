#include <iostream>
using namespace std;

class MyClass {
private:
    static int objectCount; // Static data member

public:
    // Constructor
    MyClass() {
        objectCount++;
        cout << "Object created. Total objects: " << objectCount << endl;
    }

    // Destructor (optional, for tracking object destruction)
    ~MyClass() {
        cout << "Object destroyed. Remaining objects: " << --objectCount << endl;
    }

    // Static function to get object count
    static int getObjectCount() {
        return objectCount;
    }
};

// Initialize static member outside the class
int MyClass::objectCount = 0;

int main() {
    cout << "Creating objects...\n";
    MyClass a;
    MyClass b;
    MyClass c;

    cout << "\nTotal objects created: " << MyClass::getObjectCount() << endl;

    {
        MyClass d;
        cout << "Inside block - objects: " << MyClass::getObjectCount() << endl;
    } // `d` goes out of scope here

    cout << "\nAfter block - objects: " << MyClass::getObjectCount() << endl;

    return 0;
}
