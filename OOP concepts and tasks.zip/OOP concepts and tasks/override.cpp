#include <iostream>
using namespace std;
// AC\overline{D}+\overline{C}D+A\overline{B}+ABCD
// Base class
class Hotel {
public:
    virtual void bookRoom() { // Virtual function
        cout << "Room booked in the standard hotel.\n";
    }
};

// Derived class
class LuxuryHotel : public Hotel {
public:
    void bookRoom() override { // Overriding the base class method
        cout << "Luxury suite booked with VIP services.\n";
    }
};

int main() {
    Hotel *h; // Base class pointer
    LuxuryHotel lh;
    
    h = &lh;  // Base class pointer pointing to derived class object
    h->bookRoom(); // Calls the overridden function in LuxuryHotel

    return 0;
}

// =========WITHOUT POINTERS , WITHOUT INHERITANCE , WITHOUT VIRTUAL AND OVERRIDE FAILS==============

// ==============For without pointers==================== 
/*
#include <iostream>
using namespace std;

class Animal {
public:
    virtual void makeSound() { // Virtual function
        cout << "Animal makes a sound\n";
    }
};

class Dog : public Animal {
public:
    void makeSound() override { // Overridden function
        cout << "Dog barks\n";
    }
};

int main() {
    Animal a; // Base class object
    Dog d;    // Derived class object

    a.makeSound(); // Calls Animal's function (STATIC BINDING)
    d.makeSound(); // Calls Dog's function (DIRECT CALL, not overriding)

    return 0;
}   */

/*
======================Also Occurs==================
int main() {
    Dog d;
    Animal& a = d;  // Base class reference to derived class object

    a.makeSound(); // Calls overridden function in Dog

    return 0;
}

*/