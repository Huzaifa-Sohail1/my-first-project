#include <iostream>
#include <string>
using namespace std;
class shape
{
private:
    int age;

protected:
    float length;
    float width;

public:
string name;

    shape()
    {
        age = 50;
        length = 0.0f;
        width = 0.0f;
    }
    shape(float l ,float w){
        length =l;
        width =w;
        cout << "length is :" << length << endl;
        cout << "width is :" << width << endl;
    }
   float calcarea(){
        
        return 0 ;
    }
    float calcarea(float l, float w) {
        return 0;
    }
    void display(){
        cout << "name is :" << name << endl;
        cout << "age is :"  << age << endl;
        cout << "length is :" << length << endl;
        cout << "width is :" << width << endl;
    }

}; 
class Square : protected shape {
    public:
        // Constructor that calls Shape constructor
        Square(float side) : shape(side, side) {
            cout << "Square Constructor: Side = " << side << endl;
        }
        float calcarea(float l, float w) {
            return l*l;
        }
    };
int main()
{   
    shape s1(5,6);
    s1.name = "Ali";
    s1.display();
    cout << "Area is :" << s1.calcarea() <<endl;
// by passing parameters 
    cout << "Area is :" << s1.calcarea(8,9) <<endl;     //overload

    Square sq(5);
    cout << "Area using provided values (8, 10): " << sq.calcarea(8, 10) << endl;


    return 0;
}

/*
#include <iostream>
#include <string>
using namespace std;

class shape {
private:
    int age;

protected:
    float length;
    float width;

public:
    string name;

    // Default Constructor
    shape() {
        age = 50;
        length = 0.0f;
        width = 0.0f;
    }

    // Parameterized Constructor
    shape(float l, float w) {
        length = l;
        width = w;
        cout << "Shape Constructor: length = " << length << endl;
        cout << "Shape Constructor: width = " << width << endl;
    }

    // Function to calculate area (should return actual area)
    float calcarea() {
        return length * width;
    }

    float calcarea(float l, float w) {
        return l * w;
    }

    void display() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Length: " << length << endl;
        cout << "Width: " << width << endl;
    }
};

// Derived class using Protected Inheritance
class Square : protected shape {
public:
    // Constructor that calls Shape constructor
    Square(float side) : shape(side, side) {
        cout << "Square Constructor: Side = " << side << endl;
    }

    // Public method to access protected members
    void showSquare() {
        display();
    }

    // Public method to use calcarea
    float getArea() {
        return length * length; // Since it's a square
    }
};

int main() {
    shape s1(5, 6);
    s1.name = "Ali";
    s1.display();
    cout << "Area is: " << s1.calcarea() << endl;

    // Calling overloaded function
    cout << "Area using provided values (8, 9): " << s1.calcarea(8, 9) << endl;

    // Creating a Square object
    Square sq(5);

    // Access protected members through a public function
    sq.showSquare();
    cout << "Square Area: " << sq.getArea() << endl;

    return 0;
}
*/