#include<iostream>
using namespace std;

class shape {
private:
    string name; 
protected:
    float length;
    float width; 

public:
    shape() {
        length = 0;                                        // default base
        width = 0;
        cout << "Shape default constructor" << endl;
    }
    shape(float l, float w) {                              // const of base 
        length = l;                                        
        width = w;
    }
    float calcArea() {
        cout << "No formula" << endl;                      // func without perimeters
        return 0;
    }

    float calcPerimeter() {
        cout << "No formula" << endl;
        return 0;
    }
};

class rectangle : public shape {
public:
    rectangle() : shape() { 
        cout << "Rectangle default constructor" << endl;  // constructor delegation in inheritance,                                                    
    }                                                     // specifically constructor initialization                                                                     
    rectangle(float l, float w) : shape(l, w) {           // in derived classes in Object-Oriented Programming (OOP).  2 parameters
        cout << "Rectangle parameterized constructor" << endl;   // ALSO IT TAKES VALUED VALUE OF l,w
    }
    rectangle(float length) {                        // 1 parameter for square clarity
       this-> length = length;
    }

    float calcArea() {
        return length * width;
    }

    float calcPerimeter() {
        return 2 * (length + width);
    }
};

class square : public rectangle {
public:
    square() : rectangle() {
        cout << "Square default constructor" << endl;
    }

    square(float side) : rectangle(side, side) {                  // rect one parameter func can also taken say : rectangle (side) now
        cout << "Square parameterized constructor" << endl;
    }

    float calcArea() {
        return length * length;
    }
    float calcPerimeter() {
        return 4 * length;
    }
};

int main() {
    rectangle r1;
    cout << "Area of rectangle:" << r1.calcArea() << endl;
    cout << "Perimeter of rectangle:" << r1.calcPerimeter() << endl;

    rectangle r2(35, 10.0);
    cout << "Area of rectangle: " << r2.calcArea() << endl;
    cout << "Perimeter of rectangle: " << r2.calcPerimeter() << endl;

    square s1;
    cout << "Area of square: " << s1.calcArea() << endl;
    cout << "Perimeter of square: " << s1.calcPerimeter() << endl;

    square s2(8);
    cout << "Area of square: " << s2.calcArea() << endl;
    cout << "Perimeter of square: " << s2.calcPerimeter() << endl;
    return 0;
}
/*============================================================
                     RETURNS MULTIPLE VALUES
#include <iostream>
using namespace std;

// Base class: Shape
class shape {
protected:
    float length, width;

public:
    shape(float l = 0, float w = 0) : length(l), width(w) { }
};

// Derived class: Rectangle
class rectangle : public shape {
public:
    rectangle(float l = 0, float w = 0) : shape(l, w) { }

    // Using reference parameters to return multiple values
    void getAreaAndPerimeter(float &area, float &perimeter) {
        area = length * width;
        perimeter = 2 * (length + width);
    }
};

int main() {
    rectangle r1(5, 10);
    float area, perimeter;

    // Call function with reference parameters
    r1.getAreaAndPerimeter(area, perimeter);
    
    cout << "Area: " << area << ", Perimeter: " << perimeter << endl;
    return 0;
}
=======================================================================================
*/
/*
==============  WITH POINTERS SAME CODE
#include <iostream>
using namespace std;

// Base class: Shape
class shape {
protected:
    float length, width;

public:
    // Parameterized constructor
    shape(float l, float w) {
        length = l;
        width = w;
    }

    // Virtual function to calculate and return area & perimeter
    virtual void getAreaAndPerimeter(float &area, float &perimeter) {
        cout << "No formula for generic shape" << endl;
        area = 0;
        perimeter = 0;
    }
};

// Derived class: Rectangle
class rectangle : public shape {
public:
    // Calls the base class constructor
    rectangle(float l, float w) : shape(l, w) { }

    // Overriding function to return both area and perimeter
    void getAreaAndPerimeter(float &area, float &perimeter) override {
        area = length * width;
        perimeter = 2 * (length + width);
    }
};

int main() {
    // Create a rectangle object using a pointer
    rectangle *r1 = new rectangle(5, 10);
    float area, perimeter;

    // Call the function using the pointer
    r1->getAreaAndPerimeter(area, perimeter);

    cout << "Rectangle Area: " << area << ", Perimeter: " << perimeter << endl;

    // Free allocated memory
    delete r1;

    return 0;
}
*/

//======================                      ==============================
/*
     1)   rectangle(float l = 0, float w = 0) : shape(l, w) { }            // FOR INHERITANCE

     2)   rectangle(float l = 0, float w = 0) : length(l), width(w) { }      // does without inheritance but also not in inheritance

Does two things at the same time:

Acts as a Default Constructor → If no arguments are provided, it initializes l = 0 and w = 0.
Acts as a Parameterized Constructor → If arguments are provided, it initializes length = l and width = w using the base class constructor.*/