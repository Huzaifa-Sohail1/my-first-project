#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int rollNumber;
    float gpa;
    int age;
    string department;

public:
    Student() {
        name = "";
        rollNumber = 0;
        gpa = 0.0;
        age = 0;
        department = "";
    }

    void inputDetails() {
        cout << "Enter Student Name: ";
        cin.ignore();  
        getline(cin, name);
        
        cout << "Enter Roll Number: ";
        cin >> rollNumber;
        
        cout << "Enter GPA: ";
        cin >> gpa;
        
        cout << "Enter Age: ";
        cin >> age;
        
        cout << "Enter Department: ";
        cin.ignore();
        getline(cin, department);
        
        cout << "---------------------------------" << endl;
    }

    void displayDetails() {
        cout << "Student Name: " << name << endl;
        cout << "Roll Number: " << rollNumber << endl;
        cout << "GPA: " << gpa << endl;
        cout << "Age: " << age << endl;
        cout << "Department: " << department << endl;
        cout << "---------------------------------" << endl;
    }
};

int main() {
    const int SIZE = 5;  
    Student students[SIZE];  

    for (int i = 0; i < SIZE; i++) {
        cout << "\nEnter details for Student " << (i + 1) << ":" << endl;
        students[i].inputDetails();
    }

    cout << "\nDisplaying Student Details:" << endl;
    for (int i = 0; i < SIZE; i++) {
        students[i].displayDetails();
    }

    return 0;
}
