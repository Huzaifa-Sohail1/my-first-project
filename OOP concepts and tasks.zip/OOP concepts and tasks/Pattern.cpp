#include <iostream>
using namespace std;

int main() {
    int n = 3; // You can take user input instead of a fixed value

    for (int i = 1; i <= n; i++) {
        // Print spaces and numbers in one loop
        for (int j = 1; j <= n + i - 1; j++) {      
            if (j <= n - i) {                      
                cout << " "; // Print spaces
            } else if (j <= n) {
                cout << j - (n - i); // Print increasing numbers
            } else {
                cout << (2 * n - j); // Print decreasing numbers
            }
        }
        cout << endl; // Move to the next line
    }
    return 0;
}

 /*   1
   121
  12321 */