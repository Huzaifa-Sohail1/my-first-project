//Run Time Polymorphism Virtual
//========================== Multiple Derive class ========================

#include <iostream>
using namespace std;

class Base {
public:
    virtual void show() {
        cout << "Base class show()" << endl;
    }
};

class Derived1 : public Base {
public:
    void show() override {
        cout << "Derived1 class show()" << endl;
    }
};

class Derived2 : public Base {
public:
    void show() override {
        cout << "Derived2 class show()" << endl;
    }
};

int main() {
    Base* bptr;
    Derived1 d1;
    Derived2 d2;

    bptr = &d1;
    bptr->show(); // Calls Derived1's show()

    bptr = &d2;
    bptr->show(); // Calls Derived2's show()

    return 0;
}