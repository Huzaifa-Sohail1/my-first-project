#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int rollNumber;
    float gpa;
    int age;
    string department;

public:
    // Default Constructor                          //Prametrized constructor
    Student() {
        name = "";                // OR Student(string n = "", int r = 0, float g = 0.0, int a = 0, string d = "") {
                                    /*        name = n;
                                        rollNumber = r;
                                        gpa = g;
                                        age = a;
                                        department = d;
                                    }                       */
        rollNumber = 0;
        gpa = 0.0;
        age = 0;
        department = "";
    }

    // Method to input student details
    void inputDetails() {
        cout << "Enter Student Name: ";
        cin.ignore();
        getline(cin, name);
        
        cout << "Enter Roll Number: ";
        cin >> rollNumber;
        
        cout << "Enter GPA: ";
        cin >> gpa;
        
        cout << "Enter Age: ";
        cin >> age;
        
        cout << "Enter Department: ";
        cin.ignore();
        getline(cin, department);
        
        cout << "---------------------------------" << endl;
    }

    // Method to display student details
    void displayDetails() {
        cout << "Student Name: " << name << endl;
        cout << "Roll Number: " << rollNumber << endl;
        cout << "GPA: " << gpa << endl;
        cout << "Age: " << age << endl;
        cout << "Department: " << department << endl;
        cout << "---------------------------------" << endl;
    }

    // Getters
    int getRollNumber() { return rollNumber; }
    float getGPA() { return gpa; }

    // Setter for GPA
    void setGPA(float newGPA) { gpa = newGPA; }

    // Function to manually sort students by GPA (Descending Order)
    static void sortStudentsByGPA(Student students[], int size) {
        for (int i = 0; i < size - 1; i++) {
            for (int j = i + 1; j < size; j++) {
                if (students[i].getGPA() < students[j].getGPA()) {
                    // Swap students[i] and students[j]
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
        cout << "Students sorted by GPA (Highest to Lowest).\n";
    }

    // Function to find a student by roll number
    static void findStudentByRoll(Student students[], int size, int roll) {
        for (int i = 0; i < size; i++) {
            if (students[i].getRollNumber() == roll) {
                cout << "Student found:\n";
                students[i].displayDetails();
                return;
            }
        }
        cout << "No student found with Roll Number " << roll << ".\n";
    }

    // Function to display students above a certain GPA
    static void displayAboveGPA(Student students[], int size, float minGPA) {
        cout << "Students with GPA above " << minGPA << ":\n";
        bool found = false;
        for (int i = 0; i < size; i++) {
            if (students[i].getGPA() >= minGPA) {
                students[i].displayDetails();
                found = true;
            }
        }
        if (!found) {
            cout << "No students found with GPA above " << minGPA << ".\n";
        }
    }
};

int main() {
    const int SIZE = 2;
    Student students[SIZE];

    // Input details for each student
    for (int i = 0; i < SIZE; i++) {
        cout << "\nEnter details for Student " << (i + 1) << ":" << endl;
        students[i].inputDetails();
    }

    // Menu for additional functionalities
    int choice;
    do {
        cout << "\n===== Student Management Menu =====\n";
        cout << "1. Display All Students\n";
        cout << "2. Sort Students by GPA\n";
        cout << "3. Find Student by Roll Number\n";
        cout << "4. Update Student GPA\n";
        cout << "5. Display Students Above a Certain GPA\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: 
                cout << "\nDisplaying Student Details:\n";
                for (int i = 0; i < SIZE; i++) {
                    students[i].displayDetails();
                }
                break;

            case 2:
                Student::sortStudentsByGPA(students, SIZE);
                break;

            case 3: {
                int roll;
                cout << "Enter Roll Number to search: ";
                cin >> roll;
                Student::findStudentByRoll(students, SIZE, roll);
                break;
            }

            case 4: {
                int roll;
                float newGPA;
                cout << "Enter Roll Number of student to update GPA: ";
                cin >> roll;
                bool found = false;
                for (int i = 0; i < SIZE; i++) {
                    if (students[i].getRollNumber() == roll) {
                        cout << "Enter new GPA: ";
                        cin >> newGPA;
                        students[i].setGPA(newGPA);
                        cout << "GPA updated successfully!\n";
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "No student found with Roll Number " << roll << ".\n";
                }
                break;
            }

            case 5: {
                float minGPA;
                cout << "Enter minimum GPA to filter students: ";
                cin >> minGPA;
                Student::displayAboveGPA(students, SIZE, minGPA);
                break;
            }

            case 6:
                cout << "Exiting program. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Please enter a number between 1 and 6.\n";
        }
    } while (choice != 6);

    return 0;
}
