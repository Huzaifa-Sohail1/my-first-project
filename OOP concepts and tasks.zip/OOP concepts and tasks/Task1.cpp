#include <iostream>
using namespace std;

class Counter {
  private:
    int xValue;
    int yValue;

  public:
    // Setters
    void setX(int x) {
      xValue = x;
    }

    void setY(int y) {
      yValue = y;
    }

    // Getters
    int getX() {
      return xValue;
    }

    int getY() {
      return yValue;
    }
};

int main() {
  Counter myObj;
  myObj.setX(4);  // Setting x value
  myObj.setY(7);  // Setting y value
  
  cout << "x: " << myObj.getX() << ", y: " << myObj.getY();  // Printing both values
  
  return 0;
}
