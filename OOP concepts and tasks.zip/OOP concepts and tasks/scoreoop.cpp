#include <iostream>
using namespace std;

class Student {
public:
    string name;
    float cgpa;
    float scores[5];  // Fixed-size array for scores
    int numScores;    // Number of scores

    // Constructor
    Student(string n, float gpa, float sc[], int num) {
        name = n;
        cgpa = gpa;
        numScores = num;
        for (int i = 0; i < num; i++) {
            scores[i] = sc[i];  // Copy array elements
        }
    }

    // Function to manually sort scores using Bubble Sort
    void sortScores() {
        for (int i = 0; i < numScores - 1; i++) {
            for (int j = 0; j < numScores - i - 1; j++) {
                if (scores[j] > scores[j + 1]) {
                    // Swap scores[j] and scores[j+1]
                    float temp = scores[j];
                    scores[j] = scores[j + 1];
                    scores[j + 1] = temp;
                }
            }
        }
    }

    // Function to display student details
    void display() {
        cout << "Name: " << name << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << "Scores (Sorted): ";
        for (int i = 0; i < numScores; i++) {
            cout << scores[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    // Example student with 5 scores
    float scores[5] = {78.5, 92.3, 85.7, 60.2, 88.9};

    Student s1("Huzaifa", 3.9, scores, 5);

    cout << "Before Sorting:\n";
    s1.display();

    s1.sortScores();  // Sorting the scores manually

    cout << "\nAfter Sorting:\n";
    s1.display();

    return 0;
}
