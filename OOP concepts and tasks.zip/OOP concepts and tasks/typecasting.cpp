#include <iostream>
using namespace std;

int main() {
    int a = 5, b = 2;
    double result = (double)a / b;  // Explicit typecasting without its ANS = 2
    
    cout << "Result: " << result << endl;
    return 0;
}
