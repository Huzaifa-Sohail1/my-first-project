#include <iostream>
using namespace std;

class Distance {
private:
    int feet;
    int inches;

public:
    // Default constructor
    Distance(int f = 0, int i = 0) {
        feet = f;
        inches = i;
        normalize();  // Normalize the initial values
    }

    // Normalize function to convert inches > 12 into feet
    void normalize() {
        feet += inches / 12;
        inches = inches % 12;
    }

    // Overload + operator
    Distance operator+(const Distance& other) const{
        Distance result;
        result.feet = feet + other.feet;
        result.inches = inches + other.inches;
       // result.normalize();  // Ensure result is valid
        return result;
    }

    // Function to return distance in feet (as decimal)
    float toFeet() const {
        return feet + inches / 12.0f;
    }

    // Function to take input
    void input() {
        cout << "Enter feet: ";
        cin >> feet;
        cout << "Enter inches: ";
        cin >> inches;
        normalize();
    }

    // Function to display the result
    void displayInFeet() const {
        cout << "Total distance = " << toFeet() << " feet" << endl;
    }
};

int main() {
    Distance d1, d2, sum;

    cout << "Enter first distance:\n";
    d1.input();

    cout << "Enter second distance:\n";
    d2.input();

    sum = d1 + d2;

    cout << "\nAfter adding:\n";
    sum.displayInFeet();

    cout << d1.toFeet(); // gives total feet in float (real + imag) of d1

    return 0;   }