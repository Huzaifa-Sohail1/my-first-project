
#include<iostream>
using namespace std;
    class MyClass {
        public:
            explicit MyClass(const MyClass& other) {
                cout << "Explicit copy constructor called\n";
            }
        };
        
       // void foo(MyClass obj) {}
        
        int main() {
            MyClass a;
         //   foo(a);  // ❌ Error: copy constructor is explicit, can't copy implicitly
            foo(MyClass(a));  // ✅ OK: Explicit copy
        }
        