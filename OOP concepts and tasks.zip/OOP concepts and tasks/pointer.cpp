#include <iostream>
using namespace std;

int main() {
    int* ptr = new int(10);  // Dynamically allocate memory
    cout << "Before delete, ptr: " << ptr << endl;  // Prints address of allocated memory
    cout << "Before delete, *ptr: " << *ptr << endl;  // Prints value 10

    delete ptr;  // Free memory

    cout << "After delete, ptr: " << ptr << endl;  // Pointer still stores the old address!
    // cout << "After delete, *ptr: " << *ptr << endl;  // ❌ Undefined Behavior! Avoid this.

    return 0;
}
/*===================Pointer and reference===============
void modifyValue(int* p) {  // Pointer function
    *p = 50;
}

void modifyValue(int& r) {  // Reference function
    r = 50;
}

int main() {
    int x = 10;
    modifyValue(&x);  // Using pointer
    cout << x << endl;  // Output: 50

    int y = 20;
    modifyValue(y);  // Using reference
    cout << y << endl;  // Output: 50
}
*/

/*=============Smart Pointers===============
unique_ptr	Owns a resource exclusively (no sharing)
shared_ptr	Shares ownership (reference counting)
weak_ptr	Non-owning reference to shared_ptr (avoids circular dependency)

CODE========================UNIQUE POINTER==============
#include <iostream>
#include <memory>  // Required for smart pointers
using namespace std;

class Student {
public:
    string name;
    Student(string n) : name(n) {
        cout << "Student " << name << " created.\n";
    }
    ~Student() {
        cout << "Student " << name << " destroyed.\n";
    }
};

int main() {
    unique_ptr<Student> ptr1 = make_unique<Student>("Ali");  // Allocates memory
    cout << "Student name: " << ptr1->name << endl;
    
    // unique_ptr cannot be copied, but can be moved
    unique_ptr<Student> ptr2 = move(ptr1);  // Transfer ownership
    if (!ptr1) cout << "ptr1 is now empty.\n";

    return 0;
}  // `ptr2` goes out of scope and deletes the Student


======================SHARED POINTER====================
#include <iostream>
#include <memory>
using namespace std;

class Student {
public:
    string name;
    Student(string n) : name(n) {
        cout << "Student " << name << " created.\n";
    }
    ~Student() {
        cout << "Student " << name << " destroyed.\n";
    }
};

int main() {
    shared_ptr<Student> ptr1 = make_shared<Student>("Ali");
    shared_ptr<Student> ptr2 = ptr1;  // Both pointers share ownership
    
    cout << "Reference count: " << ptr1.use_count() << endl;

    return 0;
}  // The object is deleted when the last `shared_ptr` goes out of scope


========================WEAK POINTER====================
#include <iostream>
#include <memory>
using namespace std;

class Student {
public:
    string name;
    Student(string n) : name(n) {
        cout << "Student " << name << " created.\n";
    }
    ~Student() {
        cout << "Student " << name << " destroyed.\n";
    }
};

int main() {
    shared_ptr<Student> ptr1 = make_shared<Student>("Ali");
    shared_ptr<Student> ptr2 = ptr1;  // Both pointers share ownership
    
    cout << "Reference count: " << ptr1.use_count() << endl;

    return 0;
}  // The object is deleted when the last `shared_ptr` goes out of scope

*/