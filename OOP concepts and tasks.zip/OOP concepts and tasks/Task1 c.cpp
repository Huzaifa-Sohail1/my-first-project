#include <iostream>
using namespace std ;

class Counter {
	private:
		int x;
		int y;
	public:
		Counter() : x(0) , y(0) 	
		{
			
		}
		Counter (int value) : x(value) , y(0) {
			
		}
		Counter (int value,int value2) : x(value) , y(value2){
			
		}
		Counter (int value,double value2) : x(value) , y(value2){
			
		}
		
		void display ()
		{
			cout << "x = " << x << ", y =" << y << endl ;
			
		}
};


int main ()
{

	Counter counter(5 , 7);
	Counter counter1(9 , 10000);
	
	counter.display() ;
	counter1.display() ;
	
}