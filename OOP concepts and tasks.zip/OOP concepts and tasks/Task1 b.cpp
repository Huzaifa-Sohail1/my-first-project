#include <iostream>
using namespace std ;

class Counter {
	private:
		int x;
		int y;
	public:
		Counter() : x(0) , y(0) 	
		{
			
		}
		Counter (int value ) : x(value) , y(0) {
		}
		void display (){
		
			cout << "x = " << x << ", y =" << y << endl ;
			
		}										// setter store
};


int main ()
{

	Counter counter(5);
	
	counter.display() ;
	                  
}