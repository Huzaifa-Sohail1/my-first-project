#include <iostream>
#include <string>
using namespace std;
 
class Student {
public:
    string name;
    float cgpa;

    // Parameterized Constructor with CGPA Reduction Option
    Student(string n, float gpa, bool reduce = false) {
    name = n;  // Assign the name

    if (reduce) {
        cgpa = gpa - 0.1f;  // Reduce CGPA by 0.1
        if (cgpa < 0.0f) {
            cgpa = 0.0f;  // Ensure CGPA is not negative
        }
    } else {
        cgpa = gpa;  // Keep CGPA unchanged
    }
}


    // Copy Constructor (Always reduces CGPA)
    Student(const Student& s) {
    name = s.name;  // Copy the name
    cgpa = s.cgpa - 0.1f;  // Reduce CGPA by 0.1

    if (cgpa < 0.0f) {
        cgpa = 0.0f;  // Ensure CGPA is not negative
    }
}


    void setName(string n) {
        name = n;
    }

    void getInfo() const {
        cout << "Name: " << name << ", CGPA: " << cgpa << endl;
    }
};

int main() {
    Student s1("Huzaifa", 3.9);  
    s1.getInfo();  // Original student

    // Using Copy Constructor (Automatic CGPA Reduction)
    Student s2(s1);
    s2.setName("Ali");

    // Using Parameterized Constructor (Manual CGPA Reduction)
    Student s3(s1.name, s1.cgpa, true);  // Manually reducing CGPA
    s3.setName("Ahmed");

    // Using Parameterized Constructor (Without Reduction)
    Student s4(s1.name, s1.cgpa, false);  // CGPA remains same
    s4.setName("Usman");

    s2.getInfo();  // Automatic reduction (3.8)
    s3.getInfo();  // Manual reduction (3.8)
    s4.getInfo();  // No reduction (3.9)

    return 0;
}
/*==================🔹 Example of a Copy Constructor in Inheritance==================
#include <iostream>
using namespace std;

class Base {
public:
    int baseValue;

    // Base class constructor
    Base(int val) : baseValue(val) {
        cout << "Base Constructor Called\n";
    }

    // Base class copy constructor
    Base(const Base& other) : baseValue(other.baseValue) {
        cout << "Base Copy Constructor Called\n";
    }
};

class Derived : public Base {
public:
    int derivedValue;

    // Derived class constructor
    Derived(int baseVal, int derivedVal) : Base(baseVal), derivedValue(derivedVal) {
        cout << "Derived Constructor Called\n";
    }

    // Derived class copy constructor
    Derived(const Derived& other) : Base(other), derivedValue(other.derivedValue) {
        cout << "Derived Copy Constructor Called\n";
    }
};

int main() {
    Derived obj1(10, 20);  // Normal constructor call
    cout << "Copying obj1 to obj2...\n";
    Derived obj2 = obj1;   // Copy constructor call

    return 0;
}

   =========== OUTPUT ===================
Base Constructor Called
Derived Constructor Called
Copying obj1 to obj2...
Base Copy Constructor Called
Derived Copy Constructor Called
*/